import pathUtil from 'node:path';
import fs from 'node:fs';
import fsPromises from 'node:fs/promises';
import {promisify} from 'node:util';
import zlib from 'node:zlib';

const outputDirectory = pathUtil.join(import.meta.dirname, '../dist-mw-extensions/');
const mwExtensionsBaseURL = (
  process.env.MW_EXTENSIONS_BASE_URL || 'https://extensions.mistium.com'
).replace(/\/+$/, '');

const brotliCompress = promisify(zlib.brotliCompress);

const normalizeRelativePath = (relativePath) => {
  const normalized = String(relativePath).replace(/^\/+/, '').replace(/\\/g, '/');
  const parts = normalized.split('/').filter(Boolean);
  if (parts.length === 0 || parts.some(i => i === '..')) {
    throw new Error(`Invalid relative path: ${relativePath}`);
  }
  return parts.join('/');
};

const toRemoteURL = (baseURL, relativePath) => {
  const normalized = normalizeRelativePath(relativePath);
  const encodedPath = normalized
    .split('/')
    .map(i => encodeURIComponent(i))
    .join('/');
  return `${baseURL}/${encodedPath}`;
};

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const fetchRemoteFile = async (baseURL, relativePath, required = true) => {
  const url = toRemoteURL(baseURL, relativePath);
  const maxAttempts = 5;

  let lastError = null;
  for (let attemptNumber = 1; attemptNumber <= maxAttempts; attemptNumber++) {
    let response = null;
    try {
      response = await fetch(url, {
        headers: {
          // Some hosts (e.g. Cloudflare/Vercel) may return 503 for
          // requests that don't carry a browser-like User-Agent.
          'User-Agent': 'Mozilla/5.0 (compatible; Bilup/1.0)'
        }
      });
    } catch (error) {
      lastError = error;
    }

    if (response && response.ok) {
      return Buffer.from(await response.arrayBuffer());
    }

    const status = response ? response.status : null;
    // Only transient failures are worth retrying: network errors,
    // 429 (rate limited) and 5xx (temporary server errors).
    const isTransient = !response || status === 429 || status >= 500;
    if (!isTransient || attemptNumber === maxAttempts) {
      if (required) {
        if (response) {
          throw new Error(`Failed to fetch ${url}: HTTP ${status}`);
        }
        throw lastError;
      }
      return null;
    }

    const waitMs = 500 * 2 ** (attemptNumber - 1) + Math.floor(Math.random() * 500);
    console.warn(
      `[fetch] ${url} ${response ? `returned HTTP ${status}` : 'failed to connect'}, ` +
      `retrying in ${waitMs}ms (attempt ${attemptNumber + 1}/${maxAttempts})`
    );
    await sleep(waitMs);
  }
};

const fetchMWFile = async (relativePath, required = true) =>
  fetchRemoteFile(mwExtensionsBaseURL, relativePath, required);

const createFetchLogPrefix = (libraryName, type, index = null, total = null) => {
  if (index === null) {
    return `[${libraryName} ${type}]`;
  }
  if (total === null) {
    return `[${libraryName} ${type} ${index}]`;
  }
  return `[${libraryName} ${type} ${index}/${total}]`;
};

const writeCompressed = async (root, relativePath, data) => {
  const normalizedRelativePath = normalizeRelativePath(relativePath);
  const outputPath = pathUtil.join(root, `${normalizedRelativePath}.br`);
  await fsPromises.mkdir(pathUtil.dirname(outputPath), {recursive: true});
  const compressed = await brotliCompress(data);
  await fsPromises.writeFile(outputPath, compressed);
};

const extractLocalAssetPathsFromHTML = (html) => {
  const result = new Set();
  const matchAttribute = /\b(?:src|href)\s*=\s*["']([^"']+)["']/gi;
  let match;
  while ((match = matchAttribute.exec(html)) !== null) {
    const value = match[1].trim();
    if (!value || value.startsWith('data:') || value.startsWith('#') || value.startsWith('mailto:')) {
      continue;
    }

    let relativePath = null;
    if (value.startsWith('/')) {
      relativePath = value.slice(1);
    } else if (value.startsWith(`${mwExtensionsBaseURL}/`)) {
      relativePath = value.slice(mwExtensionsBaseURL.length + 1);
    } else {
      continue;
    }

    relativePath = relativePath.split('#')[0].split('?')[0];
    if (!relativePath || relativePath.endsWith('/')) {
      continue;
    }
    result.add(normalizeRelativePath(relativePath));
  }
  return result;
};

const buildMWOfflineFiles = async () => {
  console.log(`[Mistium] Preparing extension cache from ${mwExtensionsBaseURL}`);

  const tempDirectory = pathUtil.join(import.meta.dirname, '../dist-mw-extensions-temp/');
  fs.rmSync(tempDirectory, {
    recursive: true,
    force: true
  });
  console.log('[Mistium] Created temporary output directory');

  const metadataPath = 'generated-metadata/extensions-v0.json';
  console.log(`${createFetchLogPrefix('Mistium', 'required', 1, 1)} Fetching ${metadataPath}`);
  const metadataBuffer = await fetchMWFile(metadataPath, true);
  const metadata = JSON.parse(metadataBuffer.toString('utf-8'));
  console.log('[Mistium] Parsed metadata');

  const requiredFiles = new Set([metadataPath]);
  const optionalFiles = new Set([
    'index.html',
    'sitemap.xml',
    'docs-internal/scratchblocks.js'
  ]);

  for (const extension of metadata.extensions || []) {
    if (!extension || typeof extension !== 'object') {
      continue;
    }
    if (typeof extension.filename === 'string' && extension.filename) {
      const directory = extension.featured ? 'featured' : 'files';
      requiredFiles.add(`${directory}/${extension.filename}`);
    }
    if (typeof extension.image === 'string' && extension.image) {
      requiredFiles.add(extension.image);
    }
  }

  await writeCompressed(tempDirectory, metadataPath, metadataBuffer);

  let requiredCount = 1;
  let optionalCount = 0;
  const requiredTotal = requiredFiles.size;
  let requiredIndex = 1;
  for (const file of requiredFiles) {
    if (file === metadataPath) {
      continue;
    }
    requiredIndex++;
    console.log(
      `${createFetchLogPrefix('Mistium', 'required', requiredIndex, requiredTotal)} Fetching ${file}`
    );
    try {
      const data = await fetchMWFile(file, true);
      await writeCompressed(tempDirectory, file, data);
      requiredCount++;
    } catch (error) {
      console.warn(`${createFetchLogPrefix('Mistium', 'required', requiredIndex, requiredTotal)} Failed to fetch ${file}:`, error.message);
    }
  }

  let optionalIndex = 0;
  for (const file of optionalFiles) {
    optionalIndex++;
    console.log(`${createFetchLogPrefix('Mistium', 'optional', optionalIndex)} Fetching ${file}`);
    const data = await fetchMWFile(file, false);
    if (!data) {
      console.log(`${createFetchLogPrefix('Mistium', 'optional', optionalIndex)} Missing ${file}`);
      continue;
    }
    await writeCompressed(tempDirectory, file, data);
    optionalCount++;
  }

  fs.rmSync(outputDirectory, {
    recursive: true,
    force: true
  });
  fs.renameSync(tempDirectory, outputDirectory);

  console.log(
    `Fetched Mistium extensions to ${outputDirectory} (required: ${requiredCount}, optional: ${optionalCount})`
  );
};

try {
  await buildMWOfflineFiles();
} catch (error) {
  console.error(error);
  process.exit(1);
}
