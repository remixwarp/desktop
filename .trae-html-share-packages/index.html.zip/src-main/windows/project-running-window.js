const fsPromises = require('fs/promises');
const path = require('path')
const AbtractWindow = require('./abstract');
const settings = require('../settings');
const askForMediaAccess = require('../media-permissions');
const SecurityPromptWindow = require('./security-prompt');

const listLocalFiles = async () => {
  const files = await fsPromises.readdir(path.join(__dirname, '../../dist-library-files/'));
  return files.map(filename => filename.replace('.br', ''));
};

let cached = null;
const listLocalFilesCached = () => {
  if (!cached) {
    cached = listLocalFiles()
      .catch((error) => {
        console.error(error);
        return [];
      });
  }
  return cached;
};

/**
 * @param {string} url
 * @returns {string|null} eg. "https:" or null if invalid URL
 */
const getProtocol = url => {
  try {
    return new URL(url).protocol;
  } catch (e) {
    return null;
  }
};

const WEB_PROTOCOLS = ['http:', 'https:'];

class ProjectRunningWindow extends AbtractWindow {
  handlePermissionCheck (permission, details) {
    return (
      // Autoplay audio and media device enumeration
      permission === 'media' ||

      // Entering fullscreen with enhanced fullscreen addon
      permission === 'window-placement' ||

      // Notifications extension
      // Actually displaying notifications also requires handlePermissionRequest check
      permission === 'notifications' ||

      // Custom fonts menu
      permission === 'local-fonts'
    );
  }

  async handlePermissionRequest (permission, details) {
    return true;
  }

  onBeforeRequest (details, callback) {
    if (details.resourceType === 'cspReport' || details.resourceType === 'ping') {
      return callback({
        cancel: true
      });
    }

    const parsed = new URL(details.url);

    if (parsed.origin === 'https://cdn.assets.scratch.mit.edu' || parsed.origin === 'https://assets.scratch.mit.edu') {
      const match = parsed.href.match(/[0-9a-f]{32}\.\w{3}/i);
      if (match) {
        const md5ext = match[0];
        return listLocalFilesCached().then((localLibraryFiles) => {
          if (localLibraryFiles.includes(md5ext)) {
            return callback({
              redirectURL: `tw-library://./${md5ext}`
            });
          }
          callback({});
        });
      }
    }

    // 各扩展库请求始终通过对应的本地协议，由协议层统一处理
    // "云端优先、失败回退本地" 的逻辑（见 src-main/protocols.js 的 remoteFallback）。
    if (parsed.origin === 'https://extensions.turbowarp.org') {
      return callback({
        redirectURL: `tw-extensions://.${parsed.pathname}`
      });
    }

    if (parsed.origin === 'https://editors.astras.top') {
      let pathname = parsed.pathname;
      if (pathname.startsWith('/extensions')) {
        pathname = pathname.slice('/extensions'.length);
      }
      return callback({
        redirectURL: `ae-extensions://.${pathname}`
      });
    }

    if (parsed.origin === 'https://extensions.mistium.com') {
      return callback({
        redirectURL: `mw-extensions://.${parsed.pathname}`
      });
    }

    if (parsed.origin === 'https://sharkpools-extensions.vercel.app') {
      return callback({
        redirectURL: `sp-extensions://.${parsed.pathname}`
      });
    }

    super.onBeforeRequest(details, callback);
  }

  onBeforeSendHeaders (details, callback) {
    const parsed = new URL(details.url);

    if (WEB_PROTOCOLS.includes(parsed.protocol)) {
      // 关键：webRequest 的 requestHeaders 是「整体替换」而非「合并」。
      // 如果这里只传 { referer }，Chromium 会把 User-Agent / Accept / Cookie /
      // Authorization 等全部丢掉，导致大量第三方站点（B 站播放器、各扩展库页面
      // 等）直接拒绝响应——表现为"外壳能加载、内容请求不到"。
      // 因此必须在原有请求头的基础上只覆盖 referer 一项。
      const requestHeaders = {...details.requestHeaders};

      // B 站播放器会校验 referer 来源，非 B 站域名会被拒绝播放视频源。
      // 播放器子资源可能来自 *.bilivideo.com 等 CDN，所以按 referrer 识别播放器来源。
      const isBilibili = parsed.hostname === 'bilibili.com' || parsed.hostname.endsWith('.bilibili.com');
      const isFromBilibiliPlayer = details.referrer && (
        details.referrer.startsWith('https://player.bilibili.com/') ||
        details.referrer.startsWith('https://www.bilibili.com/')
      );
      const referer = (isBilibili || isFromBilibiliPlayer) ?
        'https://www.bilibili.com/' :
        // Some third-party APIs (eg. YouTube embeds) require a non-empty referer header.
        // The website being contacted already receives "bilup-desktop/x.y.z" in the user-agent so this isn't
        // revealing any metadata that they couldn't already have access to.
        'https://rw-desktop.pages.dev/docs/referer.html';

      // 复用原有 referer 的大小写形式，避免出现两份 referer 头
      let refererKey = 'referer';
      for (const key of Object.keys(requestHeaders)) {
        if (key.toLowerCase() === 'referer') {
          refererKey = key;
          break;
        }
      }
      requestHeaders[refererKey] = referer;

      return callback({
        requestHeaders
      });
    }

    callback({});
  }

  onHeadersReceived (details, callback) {
    if (
      settings.bypassCORS &&
      // Don't give extra powers when fetching our custom protocols
      WEB_PROTOCOLS.includes(getProtocol(details.url))
    ) {
      const newHeaders = {};

      const isMainFrame = details.frame === this.window.webContents.mainFrame;
      if (isMainFrame) {
        newHeaders['access-control-allow-origin'] = '*';
      }

      for (const [key, headers] of Object.entries(details.responseHeaders)) {
        switch (key.toLowerCase()) {
          case 'access-control-allow-origin':
            if (isMainFrame) {
              // Above we forced this header to be *, so ignore any other value
            } else {
              newHeaders[key] = headers;
            }
            break;

          // Remove x-frame-options so that embedding is allowed
          case 'x-frame-options':
            break;

          // Modify CSP frame-ancestors to allow embedding
          // We modify the report-only header to reduce console spam
          case 'content-security-policy':
          case 'content-security-policy-report-only': {
            // We try to add allowed origins rather than completely remove/replace to reduce possible security impact.
            const extraFrameAncestors = this.protocol ? this.protocol : null;
            if (extraFrameAncestors) {
              // Note that frame-ancestors does not fall back to default-src.
              // Regex based on ABNF from https://www.w3.org/TR/CSP3/#grammardef-serialized-policy
              newHeaders[key] = headers.map(csp => (
                csp.replace(
                  /((?:;[\x09\x0A\x0C\x0D\x20]*)?frame-ancestors[\x09\x0A\x0C\x0D\x20]+)([^;,]+)/ig,
                  (_, directiveName, directiveValue) => `${directiveName}${directiveValue} ${extraFrameAncestors}`
                )
              ));
            }
            break;  
          }

          default:
            newHeaders[key] = headers;
            break;
        }
      }

      return callback({
        responseHeaders: newHeaders
      });
    }

    super.onHeadersReceived(details, callback);
  }

  handleWindowOpen (details) {
    const parsed = new URL(details.url);
    if (parsed.protocol === 'data:') {
      // Imported lazily due to circular dependencies
      const DataPreviewWindow = require('./data-preview');
      DataPreviewWindow.open(this.window, details.url);

      return {
        action: 'deny'
      };
    }

    return super.handleWindowOpen(details);
  }
}

module.exports = ProjectRunningWindow;
